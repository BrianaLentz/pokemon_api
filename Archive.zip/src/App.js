import FetchPokemon from "./components/FetchPokemon";


function App() {
  return (
    <div>
      <FetchPokemon />
    </div>
  );
}

export default App;
